// const webpack = require('webpack')

// module.exports = {
//   publicPath: '/miao/',
//   assetsDir: '.'
// }