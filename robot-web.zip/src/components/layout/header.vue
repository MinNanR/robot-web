<template>
  <div class="header">
    <div class="brand">MIAO</div>
    <div class="header-right">
      <p>你好,{{ username }}</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: "",
    };
  },
  methods: {
    getUserInfo() {
      this.request
        .post("/common/getUserInfo", {})
        .then((response) => {
          this.username = response.data.username;
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
  mounted() {
    this.getUserInfo();
  },
};
</script>

<style>
.brand {
  font-size: 25px;
  height: 65px;
  line-height: 65px;
  color: #ffffff;
}

.header-right {
  font-size: 18px;
  line-height: 100%;
  color: #ffffff;
}

.header {
  display: flex;
  justify-content: space-between;
}
</style>