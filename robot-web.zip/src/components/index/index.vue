<template>
  <div>
    主页
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>