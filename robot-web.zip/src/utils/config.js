const config = {
    baseUrl: "http://localhost:8901/",
    // baseUrl: "https://minnan.site:2010/"
}

export default config;